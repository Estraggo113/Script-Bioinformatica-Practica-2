Práctica 2. Detección de candidatos BRAF V600E

Coloca los archivos .fasta en la carpeta centros_BRAF y deja
detectar_braf.sh junto a esa carpeta.

Abre una terminal en la carpeta del proyecto y ejecuta:

    chmod u+x detectar_braf.sh
    ./detectar_braf.sh

El script busca el fragmento CTACAGAGAAATC y guarda la cabecera y la
secuencia de cada candidato en pacientes_candidatos_BRAF.fasta.

Para contar los candidatos, ejecuta:

    grep -c '^>' pacientes_candidatos_BRAF.fasta

Con los cuatro archivos de la práctica, el resultado esperado es 14.
